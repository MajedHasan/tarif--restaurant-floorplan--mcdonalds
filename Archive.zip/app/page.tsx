import FloorPlan from "./FloorPlan";

export default function Home() {
  return (
    <main>
      <h1>Restaurant Floor Plan</h1>
      <FloorPlan />
    </main>
  );
}
